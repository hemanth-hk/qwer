//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ENBSeries is a set of graphical modifications for games. Donateware
//Description on the web page may not be equal to this info.
//created by Boris Vorontsov http://enbdev.com
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



ENBSeries DX8 to DX9 Convertor v0.036

WARNING! This is convertor of DirectX8 to DirectX9 rendering functions, not the
modification, no new effects. It works with other games as previous versions, but
developed for Silent Hill 2 and contain specific fixes for this game.



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
GAME COMPATIBILITY:
Mod may work incorrect with some versions of the games, impossible to test it for every game patch and for already modded games. Some types of installed game modifications may conflict with ENBSeries.

INSTALLING:
Extract files from archive in to the game directory or where game execution file exist (.exe).

SETTING DESCRIPTION:

[PROXY]
EnableProxyLibrary=(0,1) load 3rd party library by the mod at game start. Helps to solve problem with multiple d3d9.dll files.
InitProxyFunctions=(0,1) connect to functions of 3rd party library.
ProxyLibrary=(filename) file name of 3rd party library.




//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
DONATE:
If on Your opinion ENBSeries project must continue to live or simply it was useful for yourself, i'll be grateful for sponsoring project (or donation).



http://enbdev.com
Copyright (c) 2007-2014 Vorontsov Boris (ENB)
